#!/usr/bin/env python3

import argparse
import csv
import json
import re
import sys
from typing import Dict, Tuple, Any


# Regexes & helpers

PHONE_RE = re.compile(r'(?<!\d)(\d{10})(?!\d)')
AADHAAR_RE = re.compile(r'(?<!\d)(\d{4}\s?\d{4}\s?\d{4})(?!\d)')
PASSPORT_RE = re.compile(r'\b([A-Za-z]\d{7})\b')
EMAIL_RE = re.compile(r'^[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$')
IP_RE = re.compile(r'(?:(?:25[0-5]|2[0-4]\d|1?\d{1,2})\.){3}(?:25[0-5]|2[0-4]\d|1?\d{1,2})')
UPI_KEY_SUBSTRINGS = ('upi',)

# Keys that commonly contain phone numbers
PHONE_LIKELY_KEYS = set([
    'phone','phone_number','mobile','contact','msisdn','customer_phone','customer_mobile','contact_number'
])

# Keys that commonly represent identifiers (avoid false positives)
ID_KEY_SUBSTRINGS = ('id','order','transaction','booking','product','ticket','reference','txn','invoice','gst','price','amount')


# Masking functions

def mask_phone(num: str) -> str:
    digits = re.sub(r'\D', '', num)
    if len(digits) == 10:
        return digits[:2] + "XXXXXX" + digits[-2:]
    return digits[:2] + "****" + digits[-2:]

def mask_aadhaar(a: str) -> str:
    digits = re.sub(r'\D', '', a)
    if len(digits) == 12:
        return "XXXX XXXX " + digits[-4:]
    return "XXXX XXXX " + digits[-4:]

def mask_passport(p: str) -> str:
    p = p.strip()
    return p[0] + "******" + p[-1] if len(p) > 2 else "X" * len(p)

def mask_email(e: str) -> str:
    try:
        local, domain = e.split('@', 1)
    except Exception:
        return "masked@domain.com"
    return local[:2] + "***@" + domain

def mask_upi(u: str) -> str:
    try:
        local, domain = u.split('@', 1)
    except Exception:
        return "xx@upi"
    return local[:2] + "***@" + domain

def mask_name(n: str) -> str:
    parts = n.split()
    # Always mask as JXXX / SXXXX style
    return " ".join([p[0] + "X" * (len(p) - 1) for p in parts])

def mask_address(val: str) -> str:
    if not val:
        return ""
    return val[:3] + "****"

def mask_generic(val: str) -> str:
    s = str(val)
    if len(s) <= 2:
        return "*" * len(s)
    return s[0] + "*" * (len(s) - 2) + s[-1]


# Detection helpers

def safe_load_json(s: str) -> Dict[str, Any]:
    if s is None:
        return {}
    if isinstance(s, dict):
        return s
    try:
        return json.loads(s)
    except Exception:
        try:
            cleaned = s.replace("'", '"')
            return json.loads(cleaned)
        except Exception:
            return {}

def looks_like_full_name(name: str) -> bool:
    if not isinstance(name, str):
        return False
    tokens = [t for t in re.split(r'\s+', name.strip()) if t]
    if len(tokens) < 2:
        return False
    alpha_tokens = [t for t in tokens if re.search(r'[A-Za-z]', t)]
    return len(alpha_tokens) >= 2

def is_valid_email(val: str) -> bool:
    return isinstance(val, str) and EMAIL_RE.match(val) is not None

def is_valid_pin(val: str) -> bool:
    return isinstance(val, str) and re.fullmatch(r'\d{6}', val) is not None

def is_valid_ipv4(val: str) -> bool:
    return isinstance(val, str) and IP_RE.fullmatch(val) is not None

def contains_phone_anywhere(val: str, key: str) -> bool:
    if not isinstance(val, str):
        return False
    if PHONE_RE.search(val):
        key_l = key.lower()
        if any(sub in key_l for sub in ID_KEY_SUBSTRINGS) and key_l not in PHONE_LIKELY_KEYS:
            return False
        return True
    return False

def contains_aadhaar_anywhere(val: str) -> bool:
    if not isinstance(val, str):
        return False
    return AADHAAR_RE.search(val) is not None

def contains_passport_anywhere(val: str) -> bool:
    if not isinstance(val, str):
        return False
    return PASSPORT_RE.search(val) is not None


# Analyze one payload

def analyze_and_redact(payload: Dict[str, Any]) -> Tuple[Dict[str, Any], bool]:
    standalone_flags = {'phone': False, 'aadhaar': False, 'passport': False, 'upi': False}
    combo_flags = {'name': False, 'email': False, 'physical_address': False, 'ip_or_device': False}

    for k, v in payload.items():
        k_l = k.lower() if isinstance(k, str) else ''
        val_str = str(v) if v is not None else ""

        if 'aadhar' in k_l or 'aadhaar' in k_l:
            if contains_aadhaar_anywhere(val_str):
                standalone_flags['aadhaar'] = True
        if 'passport' in k_l:
            if contains_passport_anywhere(val_str):
                standalone_flags['passport'] = True
        if 'upi' in k_l:
            if '@' in val_str:
                standalone_flags['upi'] = True
        if k_l in PHONE_LIKELY_KEYS:
            if PHONE_RE.search(val_str):
                standalone_flags['phone'] = True
        else:
            if contains_phone_anywhere(val_str, k_l):
                standalone_flags['phone'] = True

        if contains_aadhaar_anywhere(val_str):
            standalone_flags['aadhaar'] = True
        if contains_passport_anywhere(val_str):
            standalone_flags['passport'] = True

    # Combinational checks
    if ('name' in payload and looks_like_full_name(payload.get('name'))) or \
       (payload.get('first_name') and payload.get('last_name')):
        combo_flags['name'] = True

    if 'email' in payload and is_valid_email(str(payload.get('email') or '')):
        combo_flags['email'] = True

    has_address = ('address' in payload and payload.get('address') and str(payload.get('address')).strip() != '')
    has_city = ('city' in payload and payload.get('city') and str(payload.get('city')).strip() != '')
    has_pin = False
    if 'pin_code' in payload and is_valid_pin(str(payload.get('pin_code') or '')):
        has_pin = True
    else:
        addr_text = str(payload.get('address') or '')
        if re.search(r'(?<!\d)(\d{6})(?!\d)', addr_text):
            has_pin = True

    # NEW: detect city-like word + pin inside address
    addr_contains_city_and_pin = False
    if has_address and has_pin:
        if re.search(r'[A-Za-z]+', str(payload.get('address') or '')):
            addr_contains_city_and_pin = True

    if (has_address and has_city and has_pin) or addr_contains_city_and_pin:
        combo_flags['physical_address'] = True

    if ('ip_address' in payload and is_valid_ipv4(str(payload.get('ip_address') or ''))) or \
       ('device_id' in payload and payload.get('device_id')):
        combo_flags['ip_or_device'] = True

    standalone_hit = any(standalone_flags.values())
    combo_count = sum(1 for v in combo_flags.values() if v)
    combinational_hit = combo_count >= 2
    is_pii = bool(standalone_hit or combinational_hit)

    redacted = {}
    for k, v in payload.items():
        k_l = k.lower() if isinstance(k, str) else ''
        original = v
        newval = original

        if isinstance(original, str):
            if contains_aadhaar_anywhere(original):
                newval = mask_aadhaar(original)
                redacted[k] = newval
                continue
            if contains_passport_anywhere(original):
                newval = PASSPORT_RE.sub(lambda m: mask_passport(m.group(1)), original)
                if newval == original:
                    newval = mask_passport(original)
                redacted[k] = newval
                continue
            if PHONE_RE.search(original):
                treat_as_phone = False
                if standalone_flags['phone']:
                    if not any(sub in k_l for sub in ID_KEY_SUBSTRINGS) or (k_l in PHONE_LIKELY_KEYS):
                        treat_as_phone = True
                else:
                    if k_l in PHONE_LIKELY_KEYS:
                        treat_as_phone = True
                if treat_as_phone:
                    newval = PHONE_RE.sub(lambda m: mask_phone(m.group(1)), original)
                    redacted[k] = newval
                    continue
            if any(sub in k_l for sub in UPI_KEY_SUBSTRINGS) or standalone_flags['upi']:
                if '@' in original:
                    newval = mask_upi(original)
                    redacted[k] = newval
                    continue

        if combinational_hit:
            if k_l in ('name', 'full_name'):
                if isinstance(original, str) and looks_like_full_name(original):
                    newval = mask_name(original)
                else:
                    newval = mask_generic(original)
                redacted[k] = newval
                continue
            if k_l in ('first_name', 'last_name'):
                newval = mask_name(str(original))
                redacted[k] = newval
                continue
            if k_l == 'email' and is_valid_email(str(original or '')):
                newval = mask_email(str(original))
                redacted[k] = newval
                continue
            if k_l in ('address', 'city', 'state', 'pin_code', 'state_code', 'address_proof'):
                newval = mask_generic(original)
                redacted[k] = newval
                continue
            if k_l in ('ip_address', 'device_id'):
                newval = mask_generic(original)
                redacted[k] = newval
                continue

        if standalone_hit:
            if isinstance(original, str) and PHONE_RE.search(original) and (k_l in PHONE_LIKELY_KEYS or standalone_flags['phone']):
                newval = PHONE_RE.sub(lambda m: mask_phone(m.group(1)), original)
                redacted[k] = newval
                continue
            if isinstance(original, str) and '@' in original and any(sub in k_l for sub in UPI_KEY_SUBSTRINGS):
                newval = mask_upi(original)
                redacted[k] = newval
                continue

        redacted[k] = newval

    return redacted, bool(is_pii)


def main():
    parser = argparse.ArgumentParser(description='PII Detector & Redactor (single-file)')
    parser.add_argument('input_csv', help='input CSV file path (must have record_id and Data_json columns)')
    parser.add_argument('--candidate', default='candidate_full_name', help='candidate name for output filenames (no spaces recommended)')
    args = parser.parse_args()

    infile = args.input_csv
    candidate = args.candidate.replace(' ', '_')
    out_csv_name = f"redacted_output_{candidate}.csv"

    try:
        with open(infile, newline='', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            rows = list(reader)
    except FileNotFoundError:
        print("Input CSV not found:", infile)
        sys.exit(1)

    header = rows[0].keys() if rows else []
    data_json_key = None
    for possible in ('Data_json', 'data_json', 'DataJson', 'dataJson'):
        if possible in header:
            data_json_key = possible
            break
    if data_json_key is None:
        possible_keys = [k for k in header if k != 'record_id']
        if possible_keys:
            data_json_key = possible_keys[0]
        else:
            print("Could not find Data_json column in CSV headers:", header)
            sys.exit(1)

    out_rows = []
    totals = {'records': 0, 'pii_true': 0}
    for row in rows:
        totals['records'] += 1
        record_id = row.get('record_id', '') or row.get('Record_id', '') or ''
        raw_json = row.get(data_json_key, '')

        parsed = safe_load_json(raw_json)
        redacted_payload, is_pii = analyze_and_redact(parsed)
        redacted_json_str = json.dumps(redacted_payload, ensure_ascii=False)

        out_rows.append({
            'record_id': record_id,
            'redacted_data_json': redacted_json_str,
            'is_pii': 'True' if is_pii else 'False'
        })
        if is_pii:
            totals['pii_true'] += 1

    with open(out_csv_name, 'w', newline='', encoding='utf-8') as outf:
        fieldnames = ['record_id', 'redacted_data_json', 'is_pii']
        writer = csv.DictWriter(outf, fieldnames=fieldnames)
        writer.writeheader()
        for r in out_rows:
            writer.writerow(r)

    print(f"Processed {totals['records']} records. Found PII in {totals['pii_true']} records.")
    print(f"Output written to: {out_csv_name}")
    print("Done.")

if __name__ == '__main__':
    main()
